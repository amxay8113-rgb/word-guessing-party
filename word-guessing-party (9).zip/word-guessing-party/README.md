# Word Guessing Party

A multiplayer word-guessing party game for 2–8 players. Players join a room using a code, take turns giving clues, and guess the secret word. Each turn lasts 60 seconds.

## Run locally
1. Install Node.js 18 or newer.
2. Extract this project.
3. Open a terminal in the project folder.
4. Run `npm install`.
5. Run `npm start`.
6. Open http://localhost:3000.

To play over the internet, deploy the Node.js app to a hosting service that supports WebSockets. The server must remain running while friends play.

## Notes
This is a starter prototype. Rooms are stored in memory and are cleared when the server restarts.
