const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const app = express();
const server = http.createServer(app);
const io = new Server(server);
app.use(express.static("public"));

const rooms = {};
const words = ["rainbow","mountain","guitar","elephant","pancake","spaceship","waterfall","butterfly","volcano","treasure"];
const code = () => Math.random().toString(36).slice(2,6).toUpperCase();

function publicRoom(room) {
  return { code: room.code, players: room.players.map(p => ({id:p.id,name:p.name,score:p.score})),
    started: room.started, round: room.round, totalRounds: room.players.length,
    turn: room.turn, timeLeft: room.timeLeft, clue: room.clue || "",
    clueGiver: room.players[room.turn]?.name || "", finished: room.finished };
}
function sendRoom(room) { io.to(room.code).emit("state", publicRoom(room)); }
function startTurn(room) {
  clearInterval(room.timer);
  room.word = words[Math.floor(Math.random()*words.length)];
  room.clue = ""; room.guessed = false; room.timeLeft = 60;
  room.clueGiverId = room.players[room.turn].id;
  io.to(room.code).emit("privateWord", {to:room.clueGiverId, word:room.word});
  sendRoom(room);
  room.timer = setInterval(() => {
    room.timeLeft--;
    if (room.timeLeft <= 0) endTurn(room);
    else sendRoom(room);
  }, 1000);
}
function endTurn(room) {
  clearInterval(room.timer);
  room.turn++;
  if (room.turn >= room.players.length) {
    room.finished = true; room.started = false; sendRoom(room); return;
  }
  startTurn(room);
}
io.on("connection", socket => {
  socket.on("createRoom", name => {
    const roomCode = code();
    const room = rooms[roomCode] = {code:roomCode,players:[],started:false,round:1,turn:0,finished:false};
    joinRoom(socket, room, name);
    socket.emit("created", roomCode);
  });
  socket.on("joinRoom", ({code:roomCode,name}) => {
    const room = rooms[(roomCode||"").toUpperCase()];
    if (!room || room.started || room.players.length >= 8) return socket.emit("errorMsg","Room unavailable or full.");
    joinRoom(socket, room, name);
  });
  function joinRoom(sock, room, name) {
    if (room.players.length >= 8) return sock.emit("errorMsg","Room is full.");
    room.players.push({id:sock.id,name:String(name||"Player").slice(0,18),score:0});
    sock.join(room.code); sendRoom(room);
  }
  socket.on("startGame", roomCode => {
    const room=rooms[roomCode]; if (!room || room.started || room.players.length<2) return;
    room.started=true; room.finished=false; room.turn=0; room.players.forEach(p=>p.score=0); startTurn(room);
  });
  socket.on("clue", ({code:roomCode,clue}) => {
    const room=rooms[roomCode]; if (!room || !room.started || socket.id!==room.clueGiverId) return;
    room.clue=String(clue||"").slice(0,100); sendRoom(room);
  });
  socket.on("guess", ({code:roomCode,guess}) => {
    const room=rooms[roomCode]; if (!room || !room.started || socket.id===room.clueGiverId || room.guessed) return;
    if (String(guess||"").trim().toLowerCase()===room.word.toLowerCase()) {
      room.guessed=true;
      const winner=room.players.find(p=>p.id===socket.id); if (winner) winner.score+=2;
      const giver=room.players.find(p=>p.id===room.clueGiverId); if (giver) giver.score+=1;
      io.to(room.code).emit("result",{message:`${winner?.name || "A player"} guessed it! The word was ${room.word}.`});
      sendRoom(room); setTimeout(()=>{if(room.started)endTurn(room);},1800);
    }
  });
  socket.on("disconnect", () => {
    for (const room of Object.values(rooms)) {
      room.players=room.players.filter(p=>p.id!==socket.id);
      if (!room.players.length) { clearInterval(room.timer); delete rooms[room.code]; }
      else if (room.started && room.players.length<2) { clearInterval(room.timer); room.started=false; room.finished=true; sendRoom(room); }
      else sendRoom(room);
    }
  });
});
const PORT=process.env.PORT||3000;
server.listen(PORT,()=>console.log(`Word Guessing Party running on port ${PORT}`));
