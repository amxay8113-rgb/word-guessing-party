const socket=io();let roomCode="",myId="",isGiver=false;
const $=id=>document.getElementById(id);
socket.on("connect",()=>myId=socket.id);
$("create").onclick=()=>socket.emit("createRoom",$("name").value||"Player");
$("join").onclick=()=>{roomCode=$("roomCode").value.toUpperCase();socket.emit("joinRoom",{code:roomCode,name:$("name").value||"Player"});};
socket.on("created",c=>{roomCode=c;$("lobby").hidden=true;$("game").hidden=false;$("code").textContent=c;});
socket.on("state",s=>{roomCode=s.code;$("lobby").hidden=true;$("game").hidden=false;$("code").textContent=s.code;$("players").innerHTML=s.players.map((p,i)=>`<p>${i+1}. ${escapeHtml(p.name)} — ${p.score} pts</p>`).join("");$("status").textContent=s.finished?"Game over!":s.started?"Game in progress":"Waiting for players…";$("start").hidden=s.started||s.finished;$("start").disabled=s.players.length<2;$("play").hidden=!s.started;$("timer").textContent=s.timeLeft??60;$("turn").textContent=s.started?`${s.clueGiver} is giving clues (turn ${s.turn+1}/${s.totalRounds})`:"";$("clue").textContent=s.clue?`Clue: ${s.clue}`:"Waiting for a clue…";isGiver=s.players.some(p=>p.id===myId)&&false;});
socket.on("privateWord",d=>{isGiver=true;$("giver").hidden=false;$("guesser").hidden=true;$("word").textContent=d.word;});
socket.on("state",s=>{if(s.started&&isGiver){$("giver").hidden=false;$("guesser").hidden=true;}else if(s.started){$("giver").hidden=true;$("guesser").hidden=false;}else{ $("giver").hidden=true;$("guesser").hidden=true;isGiver=false;}});
$("start").onclick=()=>socket.emit("startGame",roomCode);
$("sendClue").onclick=()=>{socket.emit("clue",{code:roomCode,clue:$("clueInput").value});$("clueInput").value="";};
$("sendGuess").onclick=()=>{socket.emit("guess",{code:roomCode,guess:$("guessInput").value});$("guessInput").value="";};
socket.on("result",r=>$("message").textContent=r.message);
socket.on("errorMsg",m=>alert(m));
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
